export default function Home() {
  return <h1 className="text-3xl font-bold underline border ring">Hello world!</h1>
}
