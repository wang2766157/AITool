# `@tailwindcss/oxide-win32-arm64-msvc`

This is the **arm64-pc-windows-msvc** binary for `@tailwindcss/oxide`
